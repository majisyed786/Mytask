using AngularBackend.Models;
using AngularBackend.Respository.Items;
using Microsoft.EntityFrameworkCore;
var builder = WebApplication.CreateBuilder(args);


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddDbContext<TaskDbContext>(options => options.UseSqlServer("name=ConnectionStrings:DefaultConnection").EnableSensitiveDataLogging().EnableThreadSafetyChecks());
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddControllers()
              .ConfigureApiBehaviorOptions(options =>
              {
                  options.SuppressConsumesConstraintForFormFileParameters = true;
                  options.SuppressInferBindingSourcesForParameters = true;
                  options.SuppressModelStateInvalidFilter = true;
                  options.SuppressMapClientErrors = true;
                  options.ClientErrorMapping[StatusCodes.Status404NotFound].Link =
                   "/Base/Error";
              })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.PropertyNamingPolicy = null;
            });

builder.Services.AddScoped<IItems, MockItemsRepository>();
var app = builder.Build();
app.UseSwagger().UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "High Schools API");
    options.DocumentTitle = "High Schools API";
});


app.UseHttpsRedirection();
app.UseRouting();
app.UseCors(p=>p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
app.UseAuthorization();
app.MapControllers();
app.Run();
