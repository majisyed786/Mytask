﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace AngularBackend.Models
{
    public class ItemsList
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Images { get; set; }
        public string? CreatedBy { get; set; } = "";
        public DateTime? CreateOn { get; set; } = DateTime.Now;
        public string? ModifyBy { get; set; } = "";
        public DateTime? ModifyOn { get; set; } = DateTime.Now;
    }
}

