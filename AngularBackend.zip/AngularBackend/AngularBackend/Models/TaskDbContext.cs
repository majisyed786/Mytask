﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Reflection.Metadata;

namespace AngularBackend.Models
{
  

    public partial class TaskDbContext(DbContextOptions<TaskDbContext> options) : DbContext(options)
    {
        
       
        /*
         *   public static string Connectionstring = "";
         protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
         {
             optionsBuilder.UseSqlServer(Connectionstring);
         }
        */
        public virtual DbSet<ItemsList> ItemsList { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.SeedInitialData();
        }
        
      
   }
    public static class InitDate
    {
        public static void SeedInitialData(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ItemsList>().HasData(
                                                         new()
                                                         {
                                                             Id=1,
                                                             Name = "Daal e Makhani",
                                                             Description = "Dal makhani is a typical vegetarian dish originating from Punjab and widespread in India. It is prepared from black lentils, red beans, tomato puree, spices and clarified butter (ghee).",
                                                             Images = "https://www.indianhealthyrecipes.com/wp-content/uploads/2021/08/chana-masala-recipe-500x500.jpg",
                                                         },
                                                          new()
                                                          {
                                                              Id=2,
                                                              Name = "Chicken Karahi",
                                                              Description = "Chicken Karahi, or Kadai chicken, is undoubtedly one of the most popular curries in and out of Pakistan and India",
                                                              Images = "https://images.immediate.co.uk/production/volatile/sites/30/2020/08/chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg",
                                                          });
        }
    }
}
