﻿using AngularBackend.Models;
using AngularBackend.Respository.Items;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AngularBackend.Controllers
{

    [ApiExplorerSettings(IgnoreApi = false)]
  

    public class ItemsController(IItems _IItemservices) : BaseController
    {
        private readonly IItems IItemservices = _IItemservices;
        [HttpGet]
        public async Task<IActionResult> GetItems(CancellationToken cancellationToken = default)
        {
            try
            {

                cancellationToken.ThrowIfCancellationRequested();
                var Result =await IItemservices.GetItems(cancellationToken);
                if (Result?.Count>0)
                    return StatusCode(StatusCodes.Status200OK, Result);
                else
                    return StatusCode(StatusCodes.Status204NoContent);

            }
            catch (Exception ex)
            {
                WriteEvent(ex.Message, "Error_Log");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddItems([FromBody]ItemsList items, CancellationToken cancellationToken)
        {
            try
            {                
                var HasAdded = await IItemservices.PostItems(items,cancellationToken);
                if (HasAdded != null)
                    return StatusCode(StatusCodes.Status200OK, items);
                else
                    return StatusCode(StatusCodes.Status501NotImplemented, "");
            
            }
            catch (Exception ex)
            {
                WriteEvent(ex.Message, "Error_Log");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateItems([FromBody] ItemsList items, [FromQuery] int Id, CancellationToken cancellationToken)
        {
            try
            {
                var HasAdded =await IItemservices.PutItems(items, Id,cancellationToken);
                if (HasAdded != null)
                    return StatusCode(StatusCodes.Status200OK, items);
                else
                    return StatusCode(StatusCodes.Status501NotImplemented, "");

            }
            catch (Exception ex)
            {
                WriteEvent(ex.Message, "Error_Log");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteItems( [FromQuery] int Id, CancellationToken cancellationToken)
        {
            try
            {
                var HasAdded =await IItemservices.DeleteItems(Id,cancellationToken);
                if (HasAdded != null)
                    return StatusCode(StatusCodes.Status200OK, Id);
                else
                    return StatusCode(StatusCodes.Status501NotImplemented, "");
            }
            catch (Exception ex)
            {
                WriteEvent(ex.Message, "Error_Log");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        private static void WriteEvent(string msg, string folderName = "")
        {
           
            try
            {   
                var Folder = string.IsNullOrEmpty(folderName) ? "Error_Log" : folderName;

                var Now = DateTime.Now;
                if (!Directory.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Folder)))
                    Directory.CreateDirectory(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Folder));

                if (!Directory.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Folder + "/" + Now.Year + "-" + Now.Month)))
                    Directory.CreateDirectory(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Folder + "/" + Now.Year + "-" + Now.Month));

                string Date = Now.ToString("dd-MM-yy");
                string path = Path.Combine(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Folder + "/" + Now.Year + "-" + Now.Month + "/"), Date + " log.txt");
                var fs = new FileStream(path, FileMode.Append, FileAccess.Write);
                var SW = new StreamWriter(fs);
                SW.WriteLine("\n****************Log Detail Start****************\n");
                SW.WriteLine("--------" + Now.ToString() + "--------\n");
                SW.WriteLine(msg);
                SW.WriteLine("\n******************Log Detail End******************\n");
                SW.Flush();
                SW.Close();
            }
            catch (Exception)
            {
            }
        }

    }
}
