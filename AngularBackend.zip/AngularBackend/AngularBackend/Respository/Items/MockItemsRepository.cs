﻿using AngularBackend.Models;
using Microsoft.EntityFrameworkCore;
namespace AngularBackend.Respository.Items
{
    public class MockItemsRepository(TaskDbContext dbContext) : IItems
    {
        private readonly TaskDbContext context = dbContext;
        public async Task<ItemsList> DeleteItems(int Id, CancellationToken cancellation=default)
        {
            try
            {
                var hasItemm = await context.ItemsList.FirstOrDefaultAsync(w => w.Id == Id, cancellationToken: cancellation);
                if (hasItemm != null)
                {
                    context.ItemsList.Remove(hasItemm);
                    await context.SaveChangesAsync(cancellation);
                    return hasItemm;
                }
                else
                    throw new Exception($"Item with Id {Id} Not Found");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<ItemsList>> GetItems(CancellationToken cancellation = default)
        {
            try
            {
             
                var hasItem = await context.ItemsList.ToListAsync(cancellationToken: cancellation);
                if (hasItem?.Count > 0)
                {
                    return hasItem;
                }
                else
                    throw new Exception("Item not found");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<ItemsList> PostItems(ItemsList items, CancellationToken cancellation = default)
        {
            if (items == null)
                throw new Exception("Not content");

            if (string.IsNullOrWhiteSpace(items.Name))
                throw new Exception("Name is required");
            
            try
                {
                var hasItem = await context.ItemsList.SingleOrDefaultAsync(w => w.Name == items.Name, cancellationToken: cancellation);
                if (hasItem != null)
                    throw new Exception("Item With same name is already exist");
                 var NewItems = new ItemsList()
                    {
                        Name = items.Name,
                        Description = items.Description,
                        Images = items.Images
                 };
                    await context.ItemsList.AddAsync(NewItems, cancellationToken: cancellation);
                    await context.SaveChangesAsync(cancellationToken: cancellation);
                    return NewItems;
                }
                catch (Exception ex)
                {

                    throw new Exception (ex.Message);
                }
         }

        public async Task<ItemsList> PutItems(ItemsList items, int Id, CancellationToken cancellation = default)
        {
            if (items == null)
                throw new Exception("Not content");

            if (string.IsNullOrWhiteSpace(items.Name))
                throw new Exception("Name is required");

            try
            {

                var hasItem = await context.ItemsList.SingleOrDefaultAsync(w => w.Id == Id, cancellationToken: cancellation);
                if (hasItem != null)
                {
                    hasItem.Name = items.Name;
                    hasItem.Description = items.Description;
                    hasItem.Images = items.Images;
                    hasItem.ModifyOn = DateTime.Now;
                    context.ItemsList.Update(hasItem);
                    await context.SaveChangesAsync(cancellationToken: cancellation);
                    return hasItem;
                }
                else
                    throw new Exception($"Item with Id {Id} Not Found");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
