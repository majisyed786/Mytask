﻿using AngularBackend.Models;
namespace AngularBackend.Respository.Items
{
    public interface IItems
    {
        public Task<List<ItemsList>> GetItems(CancellationToken cancellation = default);
        public Task<ItemsList> PostItems(ItemsList items, CancellationToken cancellation = default);
        public Task<ItemsList> PutItems(ItemsList items, int Id, CancellationToken cancellation = default);
        public Task<ItemsList> DeleteItems(int Id, CancellationToken cancellation = default);
    }
}
