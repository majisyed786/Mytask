﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AngularBackend.Migrations
{
    /// <inheritdoc />
    public partial class TaskDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ItemsList",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Images = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifyBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifyOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ItemsList", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "ItemsList",
                columns: new[] { "Id", "CreateOn", "CreatedBy", "Description", "Images", "ModifyBy", "ModifyOn", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 2, 10, 21, 57, 48, 182, DateTimeKind.Local).AddTicks(5973), "", "Dal makhani is a typical vegetarian dish originating from Punjab and widespread in India. It is prepared from black lentils, red beans, tomato puree, spices and clarified butter (ghee).", "https://www.indianhealthyrecipes.com/wp-content/uploads/2021/08/chana-masala-recipe-500x500.jpg", "", new DateTime(2024, 2, 10, 21, 57, 48, 182, DateTimeKind.Local).AddTicks(5988), "Daal e Makhani" },
                    { 2, new DateTime(2024, 2, 10, 21, 57, 48, 182, DateTimeKind.Local).AddTicks(5990), "", "Chicken Karahi, or Kadai chicken, is undoubtedly one of the most popular curries in and out of Pakistan and India", "https://images.immediate.co.uk/production/volatile/sites/30/2020/08/chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg", "", new DateTime(2024, 2, 10, 21, 57, 48, 182, DateTimeKind.Local).AddTicks(5990), "Chicken Karahi" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ItemsList");
        }
    }
}
